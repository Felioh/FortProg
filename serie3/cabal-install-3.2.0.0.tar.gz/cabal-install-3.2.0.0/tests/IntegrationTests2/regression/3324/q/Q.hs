module Q where

import P

q :: Int
q = p
