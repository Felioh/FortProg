module P where

p :: Int
p = 42
